package water_fin;

public class reservation {
    String online; //�¶���
    String offline; //��������

    public reservation(String online, String offline) {
        this.online = online;
        this.offline = offline;
    }
}